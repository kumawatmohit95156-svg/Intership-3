# Week 3 — Enhancing User Experience with Accessibility

OpenPath Learning is a responsive sample learning website designed to demonstrate practical accessibility improvements.

## Files
- `index.html`: semantic page structure, skip link, navigation, course cards, accessibility section, and FAQ
- `styles.css`: responsive layouts, color and typography, focus-visible styles, and reduced-motion support
- `script.js`: mobile navigation and accessible FAQ interactions
- `REPORT.docx`: internship report

## Run locally
Open `index.html` in a modern browser. The project uses no build tools or external JavaScript dependencies. Google Fonts are optional; fallback fonts are provided.

## Accessibility features
- Skip-to-main-content link
- Semantic header, navigation, main, section, article, and footer landmarks
- Keyboard-friendly native buttons and links
- Visible focus indicator
- ARIA-expanded state and labelled FAQ panels
- Responsive layout and reduced-motion preference
- Clear headings, readable text, and high-contrast dark/light sections

## Manual test checklist
1. Press Tab immediately after page load; the skip link should appear.
2. Activate the skip link and confirm focus/navigation moves to the main content.
3. Use Tab and Enter/Space to operate the menu and FAQ.
4. Check the menu's `aria-expanded` value while opening and closing it.
5. Open and close FAQ answers and verify their `aria-expanded` state and visibility.
6. Review mobile and desktop widths for readable content and no horizontal scrolling.
7. For a full audit, run Lighthouse Accessibility or axe/WAVE in a browser and manually review color contrast and keyboard behavior.
