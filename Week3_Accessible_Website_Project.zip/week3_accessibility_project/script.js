const menuButton = document.querySelector('.menu-toggle');
const navigation = document.querySelector('#primary-nav');

menuButton.addEventListener('click', () => {
  const opened = navigation.classList.toggle('open');
  menuButton.setAttribute('aria-expanded', String(opened));
  menuButton.querySelector('.menu-label').textContent = opened ? 'Close' : 'Menu';
});

navigation.querySelectorAll('a').forEach(link => {
  link.addEventListener('click', () => {
    navigation.classList.remove('open');
    menuButton.setAttribute('aria-expanded', 'false');
    menuButton.querySelector('.menu-label').textContent = 'Menu';
  });
});

// FAQ: delegated event handling keeps each question's state in sync with its panel.
const faqList = document.querySelector('.faq-list');
faqList.addEventListener('click', event => {
  const button = event.target.closest('.faq-trigger');
  if (!button || !faqList.contains(button)) return;
  const panel = document.getElementById(button.getAttribute('aria-controls'));
  if (!panel) return; // Safe fallback if a panel is missing.
  const expanded = button.getAttribute('aria-expanded') !== 'true';
  button.setAttribute('aria-expanded', String(expanded));
  panel.hidden = !expanded;
  button.querySelector('.faq-icon').textContent = expanded ? '−' : '＋';
});

document.querySelector('#year').textContent = new Date().getFullYear();
